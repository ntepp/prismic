package com.duocode.assigment.controllers;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

import io.prismic.Api;
import io.prismic.Cache;
import io.prismic.Document;
import io.prismic.Logger;


@Controller
public class ContentController {
	@Autowired
	private Environment env;
	
	@Autowired(required = false)
    private Cache cache;
	
    @Autowired(required = false)
    private Logger logger;
    
	@ResponseStatus(HttpStatus.NOT_FOUND)
    public static class DocumentNotFoundException extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }

	@RequestMapping(value = "/", method = RequestMethod.GET)
    public String index(ModelMap model) {
		System.out.println("End Point "+env.getProperty("prismic.api.url"));
		Api api = Api.get(env.getProperty("prismic.api.url"));
		Iterator<Document> itr = api.query().submit().getResults().iterator();
		while(itr.hasNext()) {
	         Document element = itr.next();
	         System.out.print(element.getSlug() + " ");
	      }
		System.out.println();
		 model.addAttribute("documents", api.query().submit().getResults());
        // model.addAttribute("documents", api.query().submit().getResults());
        return "index";
    }
	
}
